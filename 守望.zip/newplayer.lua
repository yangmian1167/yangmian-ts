require("TSLib")

function new()
	openURL("IGG".."://cmd/".."newrecord");
	delay(4)
end

function nextgame()
	openURL("IGG:".."//cmd/".."nextrecord");
	delay(4)
end


