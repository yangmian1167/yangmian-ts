require("TSLib")
require("tsp")
require("AWZ")


pddbid = 'com.xunmeng.pinduoduo'



t = {}
t['首页点搜索']={ 0x666666, "-255|-15|0xe02e24,127|-18|0x898989", 90, 36, 1052, 606, 1128 } --多点找色
t['搜索界面']={ 0xe02e24, "-7|20|0xf9d7d5,-238|-9|0xf7f7f7,-135|-17|0x818181", 90, 47, 1047, 607, 1120 } --多点找色
t['搜索']={ 0xf7fbff, "-51|19|0x007aff,44|-28|0x007aff,29|-44|0xd2d5db", 90, 503, 1042, 629, 1130 } --多点找色
t['客户电池物品']={ 0x1d1a1d, "-9|-158|0xf90505,61|72|0x228c42,16|163|0x333333,-143|248|0xed8c86", 90, 321, 213, 631, 682 } --多点找色

t['填地址和支付界面']={ 0x858585, "-5|18|0x969696,-4|29|0x939393,66|30|0x656565,93|17|0xcccccc,88|3|0x747474", 90, 264, 61, 372, 103 } --多点找色
	t['填地址和支付界面_添加地址']={ 0xff2741, "22|25|0xff2741,60|4|0x2f2f30,585|13|0xadadad", 90, 23, 140, 622, 191 } --多点找色
	t['填地址和支付界面_添加新收货地址']={ 0xd7d7d8, "-1|25|0x9f9f9f,24|0|0xcecece,199|-1|0x808081,206|25|0x858585", 90, 212, 205, 431, 240 } --多点找色











function buy()
	while true do
		if active(pddbid,5)	then
			if d('首页点搜索',true) then
			elseif d('搜索界面') then
				click(318,176)
				input('拾能大容量')
			elseif d('搜索',true) then
			elseif d('客户电池物品',true) then
			elseif d('填地址和支付界面') then
				if d('填地址和支付界面_添加地址',true) then
					if d('填地址和支付界面_添加新收货地址',true) then
						click(119,308)
						input()
						click(365,314)
						input()
						click(105,489)
						input()
					end
				end
			
			end
		end	
		delay(1)
	end		
	
end



buy()




















