require("TSLib")
require("tsp")
require("AWZ")
require("ALZ")
--require("iphone6s9系统放大")
require("iphone6ios11系统")

bid = {}
bid.pdd = "com.xunmeng.pinduoduo"
id= '10691'

function up(name,other)
	local url = 'http://idfa888.com/Public/idfa/?service=idfa.idfa'
	local idfalist ={}
	idfalist.phonename = phonename or getDeviceName()
	idfalist.phoneimei = phoneimei or getDeviceType(); 
	idfalist.phoneos = phoneos or getOSType(); 
	idfalist.name = name
	idfalist.idfa = idfa or phone
	idfalist.ip = ip() or "192.168.1.1" 
	idfalist.account = account
	idfalist.password = password
	idfalist.phone = phone
	idfalist.other = other
	return post(url,idfalist)
end



function reg()
	取号 = true
	发送验证码 = true
	取短信 = true
	提交 = true
	timeline = os.time()
	timeout = (math.random(3,5))*60
	
	while os.time() - timeline < timeout do
		if active(bid.pdd,5) then
			if d('首页',true) then
				
			elseif d('点击登录',true) then
			elseif d('使用其他方式登录',true) then
			
			elseif d('手机登录界面') then
				if 取号 then		
					if GET_Phone(id) then	
						click(268,  199)
						delay(2)
						inputStr(phone)
						取号 = false
						发送验证码 = true
					end
				elseif 发送验证码 then
					if d("手机登录界面_发送验证码",true) then
					else
						发送验证码 = false
						取短信 = true
					end
				elseif 取短信 then
					if getMessage(id,phone) then
						click(245,  289)
						inputStr(sms)
						取短信 = false
						提交 = true
					end
				elseif 提交 then
					if d("手机登录界面_登录",true) then
					
					end
				end
			elseif d("个人中心") then
				if d("个人中心_注册完成") then
					up("拼多多","初次注册")
					delay(3)
					return true
				end
			elseif d("tips开启消息",true) then
			elseif d("tips红包",true) then
			elseif d("tips神秘宝箱",true) then
			else
				d('tips_手机号登录',true)
			end
	
		end
		delay(2)
	end
end



--[[]]
index = 0
while (true) do
	vpnx()
	delay(3)
	if awzNew() then
		if vpn()then
			if reg()then
				reName(phone)
				delay(3)
				index = index + 1
				if index > 50 then
					return
				end
			end

		end
	end
end

--]]

















