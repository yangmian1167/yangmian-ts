-- 积分墙对接
-- jfq.lua  

-- Create By TouchSpriteStudio on 13:12:53   
-- Copyright © TouchSpriteStudio . All rights reserved.
	
	
	
	
